﻿function getParameterByName(name, url = window.location.href) {
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}
function ReplaceDangerousChars() { return this.replace(/&nl/g, '<br/>').replace(/&as/g, "'") }
String.prototype.ReplaceDanger = ReplaceDangerousChars;

function RandomString(len) { return Array.from({ length: len }, i => String.fromCharCode(Math.round(Math.ceil(Math.random() * 25) + 65))).join(''); }
Math.RandomString = RandomString;

$.makeTable = function (mydata, cssClass, HeaderMapping, callback) {
    if (!cssClass) cssClass = "display table table-bordered table-secondary table-hover table-stripped table-light";
    var table = $('<table border="1" class="' + cssClass + '">');
    var tblHeader = '<thead ><tr>';
    for (var k in mydata[0]) {
        if (HeaderMapping) tblHeader += "<th>" + HeaderMapping[k] + "</th>";
        else tblHeader += "<th>" + k + "</th>";
    }
    tblHeader += "</tr></thead>";
    $(tblHeader).appendTo(table);
    var TableRow = "<tbody>";
    $.each(mydata, function (index, value) {
        TableRow += "<tr id=_ID_>".replace("_ID_", value.name);
        $.each(value, function (key, val) {
            if (callback) TableRow += "<td>" + callback(key, val, value) + "</td>";
            else TableRow += "<td>" + val + "</td>";
        });
        TableRow += "</tr>";
    });
    TableRow += "</tbody>";
    var tblFooter = "<tfoot><tr>";
    for (var k in mydata[0]) tblFooter += "<th>" + k + "</th>";
    tblFooter += "</tr></tfoot>";
    TableRow += tblFooter;
    $(table).append(TableRow);
    return ($(table));
};
$.NavigateTo = function NavigateTo(id) {
    //window.location.href = id;
    setTimeout(() => {
        let jEleContainer = $("#" + id);
        $('html, body').animate({
            scrollTop: jEleContainer.offset().top
        }, 500);
    }, 500);
}
String.prototype.separateWord = function () { return this.replace(/([A-Z])/g, ' $1').trim() };
String.prototype.titleCase = function () {
    let str = this;
    var splitStr = str.toLowerCase().split(' ');
    for (var i = 0; i < splitStr.length; i++) {
        // You do not need to check if i is larger than splitStr length, as your for does that for you
        // Assign it back to the array
        splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
    }
    // Directly return the joined string
    return splitStr.join(' ');
}
function MoreOrLess(show_more_snippet_jID, show_more_jID, max_chars, callback) {
    if (undefined == max_chars) max_chars = 50;
    this.max_chars = max_chars;
    this.show_more_snippet_jID = show_more_snippet_jID;
    this.show_more_jID = show_more_jID;
    this.textChanged();
    let that = this;
    $(this.show_more_jID).click(function (e) {
        if ($(that.show_more_snippet_jID).text().length <= that.max_chars) {
            that.ShowMorePutLess($(e.target));
            if (callback) callback(show_more_snippet_jID, show_more_jID, MoreOrLess.ShowMorePutLess)
        }
        else {
            that.ShowLessPutMore($(e.target));
            if (callback) callback(show_more_snippet_jID, show_more_jID, MoreOrLess.ShowLessPutMore)
        }
    });
}
MoreOrLess.ShowMorePutLess = function (show_more_snippet_jID, show_more_jID) {
    let jEle = $(show_more_jID);
    if (!jEle.length) return;
    jEle.fadeOut(1000);
    $(show_more_snippet_jID).fadeOut(1000, () => {
        $(show_more_snippet_jID).text($(show_more_snippet_jID).attr('txt'));
        $(show_more_snippet_jID).fadeIn(1000);
        jEle.text(' Less...');
        jEle.fadeIn(1000);
    });
}
MoreOrLess.ShowLessPutMore = function (show_more_snippet_jID, show_more_jID, max_chars) {
    let jEle = $(show_more_jID);
    if (!jEle.length) return;
    jEle.fadeOut(1000);
    $(show_more_snippet_jID).fadeOut(1000, () => {
        $(show_more_snippet_jID).text($(show_more_snippet_jID).attr('txt').substring(0, max_chars));
        $(show_more_snippet_jID).fadeIn(1000);
        jEle.text(' More...');
        jEle.fadeIn(1000);
    });
}
MoreOrLess.prototype.ShowLessPutMore = function (jEle) { MoreOrLess.ShowLessPutMore(this.show_more_snippet_jID, this.show_more_jID, this.max_chars) }
MoreOrLess.prototype.ShowMorePutLess = function (jEle) { MoreOrLess.ShowMorePutLess(this.show_more_snippet_jID, this.show_more_jID); }
MoreOrLess.prototype.textChanged = function () {
    let Text = $(this.show_more_snippet_jID).text();
    $(this.show_more_snippet_jID).attr('txt', Text);
    if (Text.length > this.max_chars) {
        $(this.show_more_snippet_jID).text(Text.substring(0, this.max_chars));
        $(this.show_more_jID).show();
    }
    else $(this.show_more_jID).hide();
}
Array.prototype.max = function () {
    return Math.max.apply(null, this);
};

Array.prototype.min = function () {
    return Math.min.apply(null, this);
};
function exportToExcel(table_conatainer_id) {
    var location = 'data:application/vnd.ms-excel;base64,';
    //var location = 'data:text/html;charset=UTF-8;name=urvashi'; //Chrome Will not allow it
    let style = `<style>
                    table {
                      font-family: Arial, Helvetica, sans-serif;
                      border-collapse: collapse;
                      width: 100%;
                      font-size:12px;
                    }

                     td,  th {
                      border: 1px solid #ddd;
                      padding: 8px;
                    }

                    tr:nth-child(even){background-color: #f2f2f2;}

                    tr:hover {background-color: #ddd;}

                    th {
                      padding-top: 12px;
                      padding-bottom: 12px;
                      font-weight:800;
                      font-size:16px;
                      text-align: left;
                      background-color: #04AA6D;
                      color: white;
                    }
                </style>`;
    var excelTemplate = '<html> ' +
        '<head> ' +
        '<meta http-equiv="content-type" content="text/plain; charset=UTF-8"/> ' + style +
        '</head> ' +
        '<body>' +
        document.getElementById(table_conatainer_id).outerHTML +
        '</body> ' +
        '</html>'
    //window.location.href = location + encodeURI(excelTemplate);
    //window.location.href = location + excelTemplate;
    window.location.href = location + window.btoa(unescape(encodeURIComponent(excelTemplate)));
}
function exportToHTML(table_conatainer_id) {
    let style = `<style>
                    table {
                      font-family: Arial, Helvetica, sans-serif;
                      border-collapse: collapse;
                      width: 100%;
                      font-size:12px;
                    }

                     td,  th {
                      border: 1px solid #ddd;
                      padding: 8px;
                    }

                    tr:nth-child(even){background-color: #f2f2f2;}

                    tr:hover {background-color: #ddd;}

                    th {
                      padding-top: 12px;
                      padding-bottom: 12px;
                      font-weight:800;
                      font-size:16px;
                      text-align: left;
                      background-color: #04AA6D;
                      color: white;
                    }
                </style>`;
    var excelTemplate = '<html> ' +
        '<head> <link href="/CMMiActions/Content/Images/CMMi.ico" rel="icon">' +
        '<meta http-equiv="content-type" content="text/plain; charset=UTF-8"/> ' + style +
        '</head> ' +
        '<body>' +
        document.getElementById(table_conatainer_id).outerHTML +
        '</body> ' +
        '</html>';
    // Fixes dual-screen position                             Most browsers      Firefox
    const dualScreenLeft = window.screenLeft !== undefined ? window.screenLeft : window.screenX;
    const dualScreenTop = window.screenTop !== undefined ? window.screenTop : window.screenY;
    let w = 1000, h = 800;
    const width = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width;
    const height = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height;

    const systemZoom = width / window.screen.availWidth;
    const left = (width - w) / 2 / systemZoom + dualScreenLeft
    const top = (height - h) / 2 / systemZoom + dualScreenTop

    var newWindow = window.open("", "dynamicContentWindow", `
      scrollbars=yes,
      width=${w / systemZoom}, 
      height=${h / systemZoom}, 
      top=${top}, 
      left=${left}
      `);
    if (newWindow) { // Check if the window was successfully opened
        newWindow.document.write(excelTemplate);
        newWindow.document.close(); // Close the document stream to ensure content is rendered
    } else {
        alert("Pop-up blocked! Please enable pop-ups for this site.");
    }
}
function exportCSVExcel(e, table_id) {
    var tableElement = document.getElementById(table_id);
    var sourceData = "data:text/csv;charset=utf-8,";
    var i = 0;
    while (row = tableElement.rows[i]) {
        sourceData += ([
            row.cells[0].innerText.replace(/\n/g, ''),
            row.cells[1].innerText.replace(/\n/g, ''),
            row.cells[2].innerText.replace(/\n/g, ''),
            row.cells[3].innerText.replace(/\n/g, '')
        ]).join(",") + "\r\n";
        i++;
    }
    $(e.target).attr({ href: encodeURI(sourceData) })
    //window.location.href = encodeURI(sourceData);
}
