﻿<%@ Application Codebehind="Global.asax.cs" Inherits="Sakila.MvcApplication" Language="C#" %>
